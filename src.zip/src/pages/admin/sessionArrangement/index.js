import React from "react";

const SessionArrangement = () => {
  return <div>SessionArrangement</div>;
};

export default SessionArrangement;
