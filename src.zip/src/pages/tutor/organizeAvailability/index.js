import React from 'react'

const OrganizeAvability = () => {
  return (
    <div>OrganizeAvability</div>
  )
}

export default OrganizeAvability