import React from "react";

const SessionRegister = () => {
  return <div>SessionRegister</div>;
};

export default SessionRegister;
