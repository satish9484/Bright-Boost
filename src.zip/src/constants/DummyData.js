export const dashCards = [
  {
    cardId: 1,
    cardTitle: "Newely enrolled patients",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
    // subCard: true
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
  {
    cardTitle: "Patient with most recentabnormal readings",
    patientCount: "354",
    dashUserImg: "images/user-img.svg",
  },
];

export const nextPatients = [
  {
    nextPatientsTitle: "Patrick doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet.",
  },
  {
    nextPatientsTitle: "Nick mannion",
    nextPatientsTime: "2:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "Lara zamora",
    nextPatientsTime: "5:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "John doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "Patrick doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet.",
  },
  {
    nextPatientsTitle: "Nick mannion",
    nextPatientsTime: "2:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "Lara zamora",
    nextPatientsTime: "5:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "John doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "Patrick doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet.",
  },
  {
    nextPatientsTitle: "Nick mannion",
    nextPatientsTime: "2:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "Lara zamora",
    nextPatientsTime: "5:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
  {
    nextPatientsTitle: "John doe",
    nextPatientsTime: "4:30 pm",
    nextPatientsDetail:
      "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur.",
  },
];

const tutorsAvability = {
  Math: {
    raj: [
      { date: 123, availability: true, subjectName: "Math", name: "Dave" },
      { date: 123, availability: true },
    ],
  },
  reno: [
    {
      name: "Dave",
      date: 123,
      availability: true,
      subjectName: "Math",
      sessionAssign: true,
      sesstionSlot: [
        { startTime: "3:00", endtime: "3:59", studentName: "Naruto" },
        { startTime: "4:00", endtime: "5:00", studentName: "Benny" },
      ],
    },
    { date: 123, availability: true },
  ],
};
